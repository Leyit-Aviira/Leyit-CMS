<?php
// pages/domy.php
?>
<section class="page-content">
    <div class="container">
        <h1>Domy</h1>
        <p>Poznaj nowoczesne projekty domów wykonanych z płyt betonowych modułowych, które łączą elegancję z funkcjonalnością.</p>
    </div>
</section>
