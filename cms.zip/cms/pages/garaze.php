<?php
// pages/garaze.php
?>
<section class="page-content">
    <div class="container">
        <h1>Garaże</h1>
        <p>Nasze garaże to połączenie funkcjonalności, trwałości oraz nowoczesnego designu, wykonane z płyt betonowych modułowych.</p>
    </div>
</section>
