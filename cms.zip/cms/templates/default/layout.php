<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>
        <?php
        require_once 'config.php';
        $stmt = $pdo->query("SELECT site_name FROM settings WHERE id = 1");
        $site = $stmt->fetch(PDO::FETCH_ASSOC);
        echo htmlspecialchars($site['site_name']);
        ?>
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Podłączenie trzech plików CSS -->
    <link rel="stylesheet" href="templates/<?php echo TEMPLATE_FOLDER; ?>/css/global.css">
    <link rel="stylesheet" href="templates/<?php echo TEMPLATE_FOLDER; ?>/css/layout.css">
    <link rel="stylesheet" href="templates/<?php echo TEMPLATE_FOLDER; ?>/css/components.css">
</head>
<body>

    <!-- Stały nagłówek -->
    <header class="site-header">
        <div class="container header-container">
            <div class="logo">
                <span class="logo-icon">&#127969;</span>
                <span class="logo-text"><?php echo htmlspecialchars($site['site_name']); ?></span>
            </div>
            <nav class="site-nav">
                <ul>
                    <li><a href="index.php?page=home">Strona Główna</a></li>
                    <li><a href="index.php?page=garaze">Garaże</a></li>
                    <li><a href="index.php?page=domy">Domy</a></li>
                    <li><a href="index.php?page=gallery">Galleria</a></li>
                    <li><a href="index.php?page=kalkulator" class="calc-btn">Kalkulator</a></li>
                    <li><a href="index.php?page=kontakt">Kontakt</a></li>
                </ul>
            </nav>
            <div class="auth-links">
                <?php if (isset($_SESSION['user'])): ?>
                    <span>Witaj, <?php echo htmlspecialchars($_SESSION['user']['username']); ?></span>
                    <a href="index.php?page=logout">Wyloguj</a>
                <?php else: ?>
                    <a href="index.php?page=login">Logowanie</a> |
                    <a href="index.php?page=register">Rejestracja</a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <!-- Główna zawartość -->
    <div class="main-content">
        <?php echo $content; ?>
    </div>

    <!-- Stopka – zawsze na dole -->
    <footer class="site-footer">
        <div class="container">
            <p>&copy; <?php echo date("Y"); ?> HP Domy i Garaże. Wszelkie prawa zastrzeżone.</p>
        </div>
    </footer>

</body>
</html>
